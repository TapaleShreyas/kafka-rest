package com.inventories.controller;

import com.inventories.kafka.KafkaConsumer;
import com.inventories.kafka.KafkaProducer;
import com.inventories.model.BrandEntity;
import com.inventories.util.ArrayListCustomMessage;
import com.inventories.resource.MultiResource;
import com.inventories.model.CustomMessage;
import com.inventories.service.BrandService;
import com.inventories.util.CustomErrorType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.PagedResources;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;
import org.springframework.hateoas.Resources;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping(value = "/api/brand")
public class BrandController {
    public static final Logger logger = LoggerFactory.getLogger(BrandController.class);

    @Autowired
    BrandService brandService;

    @Autowired
    KafkaProducer kafkaProducer;

    @Autowired
    KafkaConsumer kafkaConsumer;

    @Value("${spring.kafka.consumer.group-id}")
    String kafkaGroupId;

    @Value("${inventories.kafka.post.brand}")
    String postBrandTopic;

    @Value("${inventories.kafka.put.brand}")
    String putBrandTopic;

    @Value("${inventories.kafka.patch.brand}")
    String patchBrandTopic;


    @GetMapping(value="/getAll")
    public ResponseEntity<?> getAllBrand(){
    	logger.info("Fetching all brands");
    	List<BrandEntity> brand = null;
    	try {
    		brand = brandService.getAllBrand();
    	} catch (Exception e){
    		logger.error("An error occurred! {}", e.getMessage());
    		CustomErrorType.returnResponsEntityError(e.getMessage());
    	}
    	return new ResponseEntity<List<BrandEntity>>(brand, HttpStatus.OK);
    }
    
    @GetMapping(value="/{id}")
    public ResponseEntity<?> getBrandById(@PathVariable("id") int id){
        logger.info("Fetching brand with ID {}", id);
        BrandEntity brand = null;
        try{
            brand = kafkaConsumer.getBrandEntityFromKafka(id);
            if (brand.getId() == 0) brand = brandService.findById(id);
        } catch (Exception e){
            logger.error("An error occurred! {}", e.getMessage());
            CustomErrorType.returnResponsEntityError(e.getMessage());
        }
        return new ResponseEntity<BrandEntity>(brand, HttpStatus.OK);
    }


    @PostMapping(value = "", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<?> addLayeredBrand(@RequestBody BrandEntity brandEntity){
        logger.info(("Process add new brand"));
        Resources<CustomMessage> res = null;
        try {
            kafkaProducer.postBrand(postBrandTopic, kafkaGroupId, brandEntity);
            List<CustomMessage> customMessageList = ArrayListCustomMessage.setMessage("created", HttpStatus.ACCEPTED);
            res = new Resources<>(customMessageList);
        } catch (Exception e){
            logger.error("An error occurred! {}", e.getMessage());
            CustomErrorType.returnResponsEntityError(e.getMessage());
        }
        return new ResponseEntity<>(res, HttpStatus.OK);
    }

    @PutMapping(value = "/{id}", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<?> putBrand(@PathVariable("id") int id, @RequestBody BrandEntity brandEntity){
        return putAndPatch(brandEntity, id, 0);
    }

    @PatchMapping(value = "/{id}", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<?> updateBrand(@PathVariable("id") int id, @RequestBody BrandEntity brandEntity){
        return putAndPatch(brandEntity, id, 1);
    }
    @DeleteMapping(value = "/{id}", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<?> removeBrand(@PathVariable("id") int id, @RequestBody BrandEntity brandEntity){
    	BrandEntity brand = new BrandEntity();
    	brand.setId(id);
    	brandService.removeBrand(brand);
        List<CustomMessage> customMessageList = null;
        customMessageList = ArrayListCustomMessage.setMessage("removed", HttpStatus.OK);
        Resources<CustomMessage> res = new Resources<>(customMessageList);
        return new ResponseEntity<>(res, HttpStatus.OK);
    }
    
    private ResponseEntity<Resources> putAndPatch(BrandEntity brandEntity, int id, int mode){
        logger.info("Process '{}' brand", (mode == 0 ? "put" : "patch"));
        Resources<CustomMessage> res = null;
        try {
            List<CustomMessage> customMessageList = null;
            BrandEntity brand = brandService.findById(id);
            if (brand != null) {
                customMessageList = ArrayListCustomMessage.setMessage("updated", HttpStatus.OK);
                brandEntity.setId(id);
                logger.error("brand name checlk {}", brand.getBrandName());
                brandEntity.setBrandName(brand.getBrandName());
                if (mode != 0) brandEntity.setBrandCode(brand.getBrandCode());
                kafkaProducer.postBrand((mode == 0 ? putBrandTopic : patchBrandTopic), kafkaGroupId, brandEntity);
            } else {
                customMessageList = ArrayListCustomMessage.setMessage("Brand Id" + id + " Not Found!", HttpStatus.BAD_REQUEST);
                res = new Resources<>(customMessageList);
                return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
            }
            res = new Resources<>(customMessageList);
        } catch (Exception e) {
            logger.error("An error occurred! {}", e.getMessage());
            CustomErrorType.returnResponsEntityError(e.getMessage());
        }
        return new ResponseEntity<>(res, HttpStatus.OK);
    }
    
}
