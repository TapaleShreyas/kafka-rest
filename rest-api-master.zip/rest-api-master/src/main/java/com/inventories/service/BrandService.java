package com.inventories.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.inventories.model.BrandEntity;

public interface BrandService {
    BrandEntity findAllByBrandNameIsLike(String name);
    List<BrandEntity> getAllBrand();
    BrandEntity addBrand(BrandEntity brand);
    BrandEntity findById(int id);
    BrandEntity updateBrand(BrandEntity brandEntity);
    public void removeBrand(BrandEntity brand);
}
